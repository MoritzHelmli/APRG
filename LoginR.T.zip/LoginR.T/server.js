//Initialisierung der benötigten Packages

//Webserver
const express = require('express');
const app = express();

//BodyParser
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));

//EJS Template Engine
app.engine('.ejs', require('ejs').__express);
app.set('view engine', 'ejs');

//Initialisierung der Datenbank(TingoDB)
//anlegen eines Ordners für die Datenbank, sollte noch keiner existieren
require('fs').mkdir(__dirname+'/tingodb', (err)=>{});

//TingoDB an sich initialisieren
const Db = require('tingodb')().Db;
const db = new Db(__dirname + '/tingodb', {});
const ObjectID = require('tingodb')().ObjectID;
//Anlegen einer Sammlung für 1. Benutzer("users") und 2. Anfragen("requests")
const DB_COLL_USERS = "users";
const DB_COLL_ENTRIES = "requests";


//Starten des Servers der Später mit localhost:3000 aufgerufen werden kann
const port = 3000;
app.listen(port, function(){
	console.log('listening to port ' + port);
});

//Initialisierung(?) der Session
const session = require('express-session');
app.use(session({
    secret: 'example',
    resave: false,
    saveUninitialized: true
}));


//Festlegen der Startseite (hier noch der Part, in dem uns der Anwender seinen gewünschten Usernamen mitteilt)
app.get('/',(request, response) =>{
	response.sendFile(__dirname + '/index.html');
});


//Seite zum Einloggen
app.get('/login', (request, response) =>{
    response.render('login');
})


//Überprüfen der beim Anmelden eingetragenen Daten
app.post('/check_Login', function(request, response){
    //Vom User eingetragene Daten auslesen
	const username = request.body['username'];
    const password = request.body['password'];
    //Gucken ob Benutzer Admin ist
    if(username == 'berm' && password == 'aloha195'){
            console.log('Anmeldung erfolgreich.');
            request.session['authenticated']=true;
            request.session['user']=username;
            response.redirect('/admin');
    }
    else {
        db.collection(DB_COLL_USERS).findOne({'user':username}, (err, result) => {
            if(err) {
                response.render('error', {'errorMsg':'Die angegebenen Daten sind falsch!'});
                return console.log(err);
            }
            if(password == result.pwd){
                console.log('Anmeldung erfolgreich.');
                request.session['authenticated']=true;
                request.session['user']=username;
                response.redirect('/profile');
            } else {  
                response.render('error', {'errorMsg':'Die angegebenen Daten sind falsch!'});
				return console.log(err);
            }
        });
    }
});


//Seite mit Adminfunktionen
app.get('/admin', function(request, response){
    if (request.session['authenticated'] == true && request.session['user'] == 'berm'){
		response.render('admin', {});
    }
    else {
        response.redirect('/');
    }
});

//Neue Benutzerdaten in der Datenbank speichern
app.post('/saveUser', function(request, response){
    const nUsername = request.body['username'];
    const nPassword = request.body['password'];
    const nEmail = request.body['email'];
    
	//erstellen eines Datensatzes
    const document = {
        'user': nUsername,
        'pwd': nPassword,
        'email': nEmail
    }
	
	//speichern des zuvor erstellten Datensatzes in der Datenbank
	db.collection(DB_COLL_USERS).save(document, function(err, result){
		//Fehlermeldung bei auftreten eines Fehlers innerhalb des Speichervorgangs
        if (err) return console.log(err);
        console.log('Benutzer erfolgreich zur Datenbank hinzugefügt!'); 
    });
	response.render('admin');
});

//Löschen eines Users aus der Datenbank durch den Admin
app.post('/deleteUser', function(request, response){
    const name = request.body['dUser'];
	//User in Datenbank suchen
	db.collection(DB_COLL_USERS).findOne({'user':name}, (err, result) => {
		//Sollte der User nicht existieren gibt die Konsole eine Fehlermeldung zurück
        if(err) return console.log(err); 
	//Entfernen des jeweiligen Benutzers aus der Datenbank
	db.collection(DB_COLL_USERS).remove({"_id": result._id}, function(err2, result2){
		   //sollte die ID nicht auffindbar sein, gibt die Konsole eine Fehlermeldung zurück
		   if (err2) return console.log(err2);
		   //Bestätigung des Löschvorgangs durch die Konsole
		   console.log(name + " wurde erfolgreich aus der Datenbank entfernt.")
        });
	});
    response.render('admin');
});
			

//Anzeigen des Profils des jeweiligen Benutzers
app.get('/profile', function(request, response){
	if (request.session['authenticated'] == true){
		response.render('profile', {'user': request.session['user']});
	}
	else{
		response.redirect('/');
	}
});			
			
//Beenden der aktuellen Session 
app.get('/logout', function(request, response){
	//löschen der Sessiondaten
	delete request.session['authenticated'];
	response.redirect('/');
	//eigentlich würde man hier auf die eigentliche Startseite zurückgeleitet werden
});