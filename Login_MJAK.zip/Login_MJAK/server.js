//INITIALISIEREN: EXPRESSJS
const express = require('express');
const app = express();

//INITIALISIEREN: BODYPARSER
const bodyParser = require ('body-parser');
app.use(bodyParser.urlencoded({extended: true}));

//INITIALISIEREN: EJS
app.engine('.ejs', require('ejs').__express);
app.set('view engine', 'ejs');

//SERVER ANWERFEN
const port = 3000;
app.listen(port, function(){
    console.log('listening on port ' + port);
})

//SESSION
const session = require('express-session');
app.use(session({
    secret: 'example',
    resave: false,
    saveUninitialized: true
}));

//TINGODB
//falls tingodb-Ordner noch nicht vorhanden, anlegen
require('fs').mkdir(__dirname+'/tingodb', (err)=>{});
//TINGODB initialisieren users: Collection für die Benutzer, entries: Collection für die Einträge
const DB_COLL_USERS = "users";
const DB_COLL_ENTRIES = "entries";

const Db = require('tingodb')().Db;
const db = new Db(__dirname + '/tingodb', {});
const ObjectID = require('tingodb')().ObjectID;


//RENDER: LOGIN
app.get('/login', (request, response) => {
    response.render('login');
})

//RENDER: NOTLOGGEDIN
app.get('/', function(request, response){
	response.render('index', {'message': 'Bitte anmelden.'});
});

//FORM: ONLOGIN
app.post('/onLogin', function(request, response){
    //Eingabe: User + PW holen
    const username = request.body['username'];
    const password = request.body['password'];
    //Passwort-Abfrage, Admin-Konto: "adm", PW: 123
    if(username == 'adm' && password == '123'){
            console.log('Anmeldung erfolgreich.');
            request.session['authenticated']=true;
            request.session['user']=username;
            response.redirect('/content');
    }
    else {
        db.collection(DB_COLL_USERS).findOne({'user':username}, (err, result) => {
            if(err) {
                response.render('index', {'message':'Anmeldung nicht erfolgreich!'});
                return console.log(err);
            }
            if(password == result.pwd){
                console.log('Anmeldung erfolgreich.');
                request.session['authenticated']=true;
                request.session['user']=username;
                response.redirect('/content');
            } else {  
                response.render('index', {'message':'Anmeldung nicht erfolgreich!'});
            }
        });
    }
});

//RENDER: CONTENT
app.get('/content', function(request, response){
	if (request.session['authenticated'] == true){
		response.render('content', {'user': request.session['user']});
	}
	else{
		response.redirect('/');
	}
});

//manuell User hinzufügen
app.get('/enterusers', function(request, response){
    if (request.session['authenticated'] == true && request.session['user'] == 'adm'){
		response.render('enter_user', {});
    }
    else {
        response.render('index', {'message':'Zugriff verweigert!'})
    }
});

//POST: User hinzufügen
app.post('/enternewusers', function(request, response){
    const newUsername = request.body['username'];
    const newUpassword = request.body['password'];
    const newUemail = request.body['email'];
    
    const document = {
        'user': newUsername,
        'pwd': newUpassword,
        'email': newUemail
    }

    db.collection(DB_COLL_USERS).save(document, function(err, result){
        if (err) return console.log(err);
    
        console.log('saved to DB');
    
    });
    
    response.render('enter_user');
});

//POST: User entfernen
app.post('/deleteusers', function(request, response){
    const name = request.body['delUser'];
    
    db.collection(DB_COLL_USERS).findOne({'user':name}, (err, result) => {
        if(err) return console.log(err); //Fehler abfangen

        db.collection(DB_COLL_USERS).remove({"_id": result._id}, function(err2, result2){
            if (err2) return console.log(err2); //Fehler abfangen
            
            console.log(name + " has been deleted.") //andernfalls bestätigung an die 
        });
    });
   // response.render('enter_user', {'deletedUser':name}); mit Callback, wenn ich weiß, wie man das richtig einbindet
    response.render('enter_user');
});

//LOGOUT
app.get('/logout', function(request, response){
	delete request.session['authenticated'];
	response.redirect('/');
});
