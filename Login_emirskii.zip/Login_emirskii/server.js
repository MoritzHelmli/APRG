const express = require ('express');
const app = express ();
const bodyParser = require ('body-parser');


app.use (bodyParser.urlencoded({extended: true}));
app.engine ('.ejs', require('ejs').__express);
app.set ('view engine', 'ejs');


require('fs').mkdir(__dirname+'/tingodb', (err)=>{});
const DB_COLLECTION = "users";
const Db = require('tingodb')().Db;
const db = new Db(__dirname + '/tingodb', {});
const ObjectID = require('tingodb')().ObjectID;


const session = require('express-session');
app.use(session({
    secret: 'mySecret',
    resave: false,
    saveUninitialized: false,
}));


app.listen(4000, function(){
	console.log("listening on 4000");
});


app.get('/', (request, response) => {
    response.sendFile(__dirname + '/index.html');
});


app.get('/login',(request, response) => {
    const username = request.body.username;

    response.render('login', {
        'username': username,
        'errors': []
    });
});


app.post('/user/login', (request, response) => {
    const username = request.body.username;
    const password = request.body.password;

	if(username == 'adm' && password == '123'){
            console.log('Login successful');
            request.session['authenticated']=true;
            request.session['user']=username;
            response.redirect('/content');
    }
	else {
		    db.collection(DB_COLLECTION).findOne({'user':username}, (err, result) => {
            if(err) {
                response.render('index', {'message':'Anmeldung nicht erfolgreich!'});
                return console.log(err);
            }
            if(password == result.pwd){
                console.log('Login successful');
                request.session['authenticated']=true;
                request.session['user']=username;
                response.redirect('/content');
            } 
			else {
				console.log('Login not successful');
				response.render('index', {'message':'Login not successful'});
                response.redirect('/login');
            }
        });
    }
});


app.get('/content', function(request, response){
	if (request.session['authenticated'] == true){
		response.render('content', {'user': request.session['user']});
	}
	else{
		response.redirect('/login');
	}
});


app.get('/enterusers', function(request, response){
    if (request.session['authenticated'] == true && request.session['user'] == 'adm'){
		response.render('enter_user', {});
    }
    else {
        response.render('index', {'message':'Access denied'})
    }
});


app.post('/enternewusers', function(request, response){
    const newUsername = request.body['username'];
    const newUpassword = request.body['password'];
    const newUemail = request.body['email'];
    
    const document = {
        'user': newUsername,
        'pwd': newUpassword,
        'email': newUemail
    }

    db.collection(DB_COLLECTION).save(document, function(err, result){
        if (err) return console.log(err);
    
        console.log('saved to DB');
    
    });
    
    response.render('enter_user');
});


app.get('/deleteusers', function(request, response){
    if (request.session['authenticated'] == true && request.session['user'] == 'adm'){
		response.render('delete_user', {});
    }
    else {
        response.render('index', {'message':'Access denied'})
    }
});


app.post('/deleteusers', function(request, response){
    const name = request.body['delUser'];
    
    db.collection(DB_COLLECTION).findOne({'user':name}, (err, result) => {
        if(err) return console.log(err);

        db.collection(DB_COLLECTION).remove({"_id": result._id}, function(err2, result2){
            if (err2) return console.log(err2);
            
            console.log(name + " has been deleted.")
        });
    });
    response.render('delete_user');
});


app.get('/logout', function(request, response){
	delete request.session['authenticated'];
	response.redirect('/');
});